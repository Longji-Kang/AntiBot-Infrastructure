def handler():
    print('Hello World')